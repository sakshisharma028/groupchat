package com.example.lavisha.project;

public class ProfilePic {

    String urlOfImage;
    String username;

    public ProfilePic(String urlOfImage) {
        this.urlOfImage = urlOfImage;
    }

    public String getUrlOfImage() {
        return urlOfImage;
    }

    public void setUrlOfImage(String urlOfImage) {
        this.urlOfImage = urlOfImage;
    }
}
